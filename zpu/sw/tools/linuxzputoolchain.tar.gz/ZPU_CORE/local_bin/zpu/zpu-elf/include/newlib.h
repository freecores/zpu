/* newlib.h.  Generated automatically by configure.  */
#ifndef __NEWLIB_H__

#define __NEWLIB_H__ 1

/* EL/IX level */
/* #undef _ELIX_LEVEL */

/* Newlib version */
#define _NEWLIB_VERSION "1.12.0"

/* MB_LEN_MAX */
#define _MB_LEN_MAX 1

/* ICONV enabled */
/* #undef _ICONV_ENABLED */

/*
 * ICONV converters enabled
 */
/* #undef _ICONV_CONVERTER_US_ASCII */
/* #undef _ICONV_CONVERTER_BIG5 */
/* #undef _ICONV_CONVERTER_SHIFT_JIS */
/* #undef _ICONV_CONVERTER_GB_2312_80 */
/* #undef _ICONV_CONVERTER_CP866 */
/* #undef _ICONV_CONVERTER_CP855 */
/* #undef _ICONV_CONVERTER_CP852 */
/* #undef _ICONV_CONVERTER_CP850 */
/* #undef _ICONV_CONVERTER_CP775 */
/* #undef _ICONV_CONVERTER_KOI8_U */
/* #undef _ICONV_CONVERTER_KOI8_R */
/* #undef _ICONV_CONVERTER_ISO_8859_1 */
/* #undef _ICONV_CONVERTER_ISO_8859_2 */
/* #undef _ICONV_CONVERTER_ISO_8859_4 */
/* #undef _ICONV_CONVERTER_ISO_8859_5 */
/* #undef _ICONV_CONVERTER_ISO_8859_15 */
/* #undef _ICONV_CONVERTER_EUC_JP */
/* #undef _ICONV_CONVERTER_EUC_KR */
/* #undef _ICONV_CONVERTER_EUC_TW */
/* #undef _ICONV_CONVERTER_ISO_10646_UCS_2 */
/* #undef _ICONV_CONVERTER_ISO_10646_UCS_4 */
/* #undef _ICONV_CONVERTER_UCS_2_INTERNAL */
/* #undef _ICONV_CONVERTER_UCS_4_INTERNAL */
/* #undef _ICONV_CONVERTER_UTF_16 */
/* #undef _ICONV_CONVERTER_UTF_8 */

#endif /* !__NEWLIB_H__ */

